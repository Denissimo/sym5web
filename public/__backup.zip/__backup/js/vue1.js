window.onload = function () {
    var app = new Vue({
        el: '#zz',
        data: {
            message: 'Vue!'
        }
    })
};